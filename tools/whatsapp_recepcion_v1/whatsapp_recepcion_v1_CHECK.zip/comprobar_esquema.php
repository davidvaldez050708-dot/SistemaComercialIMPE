<?php
if (PHP_SAPI !== 'cli') exit(2);
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    $site=realpath((string)getenv('IMPE_WA_CHECK_SITE'));
    if (!$site) throw new RuntimeException('Ruta no disponible');
    require $site.'/config/db_connection.php';
    $db=(new Database())->connect(false);
    $db->query('START TRANSACTION READ ONLY');
    $tables=['whatsapp_conversaciones'=>['cuenta_id','telefono_normalizado'], 'whatsapp_mensajes'=>['wamid'], 'whatsapp_webhook_eventos'=>['evento_hash']];
    foreach ($tables as $table=>$key) {
        $stmt=$db->prepare('SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?');
        $stmt->bind_param('s',$table); $stmt->execute(); $r=$stmt->get_result()->fetch_assoc(); $stmt->close();
        if(strtoupper((string)($r['ENGINE']??''))!=='INNODB') throw new RuntimeException('Motor incompatible: '.$table);
        echo 'INNODB_OK | '.$table.PHP_EOL;
        $stmt=$db->prepare('SELECT INDEX_NAME, COLUMN_NAME, SUB_PART FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND NON_UNIQUE=0 ORDER BY INDEX_NAME,SEQ_IN_INDEX');
        $stmt->bind_param('s',$table); $stmt->execute(); $res=$stmt->get_result(); $indexes=[];$partial=[];
        while($r=$res->fetch_assoc()) { $indexes[$r['INDEX_NAME']][]=$r['COLUMN_NAME']; if($r['SUB_PART']!==null)$partial[$r['INDEX_NAME']]=true; }
        $stmt->close(); $ok=false;
        foreach($indexes as $name=>$columns)if($columns===$key && empty($partial[$name]))$ok=true;
        if(!$ok) throw new RuntimeException('Falta clave unica completa: '.$table);
        echo 'CLAVE_UNICA_OK | '.$table.' | '.implode(',',$key).PHP_EOL;
    }
    $probe=$db->query("SELECT IS_FREE_LOCK('impe-wa-preflight-readonly-v1') AS disponible")->fetch_assoc();
    if(!isset($probe['disponible']) || !in_array((string)$probe['disponible'],['0','1'],true))throw new RuntimeException('Funciones de bloqueo no disponibles');
    echo 'FUNCION_IS_FREE_LOCK_OK | no se adquieren bloqueos'.PHP_EOL;
    $db->rollback();$db->close();
    echo 'ESQUEMA_CHECK_OK'.PHP_EOL;
} catch(Throwable $e) {
    if(isset($db))try{$db->rollback();}catch(Throwable $ignore){}
    // No exponer configuración, consultas completas o credenciales.
    echo 'ESQUEMA_CHECK_BLOQUEADO | '.get_class($e).PHP_EOL;
    exit(2);
}
