#!/usr/bin/env python3
# CHECK exclusivo: no aplica cambios ni ejecuta DDL/DML.
import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def blob(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def candidate(data, spec):
    if blob(data) != spec['before']:
        raise ValueError('huella instalada no reconocida')
    text = data.decode('utf-8')
    for old, new in spec['changes']:
        if text.count(old) != 1:
            raise ValueError('bloque exacto ausente o duplicado')
        text = text.replace(old, new, 1)
    result = text.encode('utf-8')
    if spec.get('after') and blob(result) != spec['after']:
        raise ValueError('huella del candidato incorrecta')
    return result

def check_schema(site):
    env = dict(os.environ, IMPE_WA_CHECK_SITE=str(site))
    result = subprocess.run(['php','-d','display_errors=0','-d','log_errors=0',str(ROOT/'comprobar_esquema.php')], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
    print(result.stdout.strip())
    if result.returncode != 0:
        raise ValueError('estructura SQL no validada')

def main():
    parser=argparse.ArgumentParser(description='Preflight de recepción WhatsApp v1, exclusivamente de lectura')
    parser.add_argument('--site',required=True)
    parser.add_argument('--check',action='store_true',required=True)
    args=parser.parse_args()
    site=Path(args.site).resolve()
    if not site.is_dir(): raise ValueError('sitio inexistente')
    if site == ROOT or site in ROOT.parents: raise ValueError('ejecutar fuera de public_html')
    manifest=json.loads((ROOT/'recepcion_v1.json').read_text(encoding='utf-8'))
    with tempfile.TemporaryDirectory(prefix='impe-wa-check-') as tmp:
        temp=Path(tmp)
        if site == temp.resolve() or site in temp.resolve().parents:
            raise ValueError('directorio temporal dentro del sitio')
        for index,(name,spec) in enumerate(manifest.items()):
            path=site/name
            if path.is_symlink() or site not in path.resolve().parents:
                raise ValueError('ruta insegura: '+name)
            try: result=candidate(path.read_bytes(),spec)
            except ValueError as exc: raise ValueError(name+': '+str(exc))
            dst=temp/('candidate_%d.php'%index)
            dst.write_bytes(result)
            lint=subprocess.run(['php','-l',str(dst)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,universal_newlines=True)
            if lint.returncode: raise ValueError('sintaxis PHP incorrecta: '+name)
            print('COMPATIBLE | '+name+' | '+spec['before']+' -> '+blob(result))
            print('SINTAXIS_OK | '+name)
        check_schema(site)
    print('CHECK_OK | 2 archivos candidatos | sin cambios al sitio ni a la base de datos')
    print('PUBLICACION_NO_AUTORIZADA | faltan pruebas MariaDB sinteticas')

if __name__=='__main__':
    try: main()
    except Exception as exc:
        print('CHECK_BLOQUEADO | '+str(exc),file=sys.stderr)
        sys.exit(2)
